# Quick Start Checklist - SAP Login Test Automation

## ☐ Pre-Setup (5 minutes)

- [ ] UIPath Studio 2024.10.1 installed and opened
- [ ] SAP login URL available
- [ ] Test credentials available
- [ ] Excel installed on machine

## ☐ Project Setup (10 minutes)

- [ ] Create new Process project: "SAP_Login_Test_Automation"
- [ ] Delete default Main.xaml
- [ ] Copy provided Main.xaml into project folder
- [ ] Create folder: `Data`
- [ ] Create folder: `Screenshots`

## ☐ Install Packages (2 minutes)

- [ ] Go to Manage Packages → Official
- [ ] Verify `UiPath.Excel.Activities` is installed (v2.24.x or later)
- [ ] Verify `UiPath.UIAutomation.Activities` is installed
- [ ] Verify `UiPath.System.Activities` is installed

## ☐ Configure Credentials (3 minutes)

**Option A: Hardcoded (Quick Test)**
- [ ] Open Main.xaml
- [ ] Find "Assign - SAP URL" activity (around line 140)
- [ ] Update value to your SAP login URL
- [ ] Find "Assign - Username" activity
- [ ] Update value to your username
- [ ] Find "Assign - Password" activity
- [ ] Update value to your password

**Option B: Config File (Recommended)**
- [ ] Create `Data/Config.xlsx`
- [ ] Add Sheet1 with columns: Key, Value
- [ ] Row 1: SAP_URL | https://your-sap-url.com
- [ ] Row 2: Username | your_username
- [ ] Row 3: Password | your_password
- [ ] Uncomment the "Config Reader" section in Main.xaml

## ☐ CRITICAL: Add Browser Automation (15-20 minutes)

This is the MOST IMPORTANT step - the XAML won't work without this!

- [ ] Open Main.xaml in UIPath Studio
- [ ] Scroll to "Comment - Browser Automation Block" activity
- [ ] **Delete the entire CommentOut activity**
- [ ] In its place, drag **"Use Application/Browser"** activity
- [ ] Click "Indicate Application to Automate"
- [ ] Open your SAP login page in browser (Chrome/Edge)
- [ ] Click on the browser window to select it
- [ ] Set URL property to variable: `sapURL`

### Inside the Browser Activity:

#### Step 1: Add Username Input
- [ ] Drag "Type Into" activity (Modern)
- [ ] Click "Indicate in Application"
- [ ] Point to Username field on SAP page
- [ ] Set Text property to: `userName`
- [ ] Check "Empty field" option
- [ ] Check "Click before typing" option

#### Step 2: Add Password Input
- [ ] Drag "Type Into" activity (Modern)
- [ ] Click "Indicate in Application"
- [ ] Point to Password field on SAP page
- [ ] Set Text property to: `userPassword`
- [ ] ✓ **CHECK "Secure Input" option (important!)**
- [ ] Check "Empty field" option

#### Step 3: Add Login Click
- [ ] Drag "Click" activity
- [ ] Click "Indicate in Application"
- [ ] Point to Login button

#### Step 4: Verify Login Success
- [ ] Drag "Check App State" activity (Modern)
- [ ] Click "Indicate in Application"
- [ ] Point to an element visible ONLY after login (user menu, dashboard, etc.)
- [ ] Set Timeout: 30000

##### In "Found" Branch:
- [ ] Add Assign: `status = "Pass"`
- [ ] Add Assign: `loginSuccess = True`
- [ ] Add Log Message: "Login Successful"

##### In "Not Found" Branch:
- [ ] Add Assign: `status = "Fail"`
- [ ] Add Assign: `errorMsg = "Home page not found"`

#### Step 5: Add Screenshot on Success
- [ ] Add "If" activity: `loginSuccess = True`
- [ ] In "Then" branch, add "Take Screenshot"
- [ ] Set save location: `"Screenshots\" + testCaseID + "_Pass_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png"`
- [ ] Set output variable: `screenshotPath`

## ☐ Test Run (5 minutes)

- [ ] Save all changes (Ctrl+S)
- [ ] Click Debug (F5) or Run (Ctrl+F6)
- [ ] Watch the automation execute
- [ ] Verify browser opens
- [ ] Verify credentials are entered
- [ ] Verify login button is clicked
- [ ] Check if login succeeds

## ☐ Verify Results (2 minutes)

- [ ] Check `Data/TestResults.xlsx` file exists
- [ ] Open TestResults.xlsx
- [ ] Verify new row with test results
- [ ] Check Status column (Pass/Fail)
- [ ] Look for screenshot in Screenshots folder
- [ ] Review screenshot to verify test execution

## ☐ Troubleshooting (if needed)

**If automation doesn't start:**
- [ ] Check if all folders exist (Data, Screenshots)
- [ ] Verify packages are installed
- [ ] Check for compilation errors in Output panel

**If browser doesn't open:**
- [ ] Verify SAP URL is correct
- [ ] Check network connectivity
- [ ] Ensure browser is installed

**If elements not found:**
- [ ] Use UI Explorer to verify selectors
- [ ] Check if SAP page loaded completely
- [ ] Increase timeout values
- [ ] Re-indicate elements using "Indicate in Application"

**If Excel error occurs:**
- [ ] Close TestResults.xlsx if open
- [ ] Verify Data folder exists
- [ ] Check write permissions on folder

## ☐ Optional Enhancements

- [ ] Add multiple test cases with different credentials
- [ ] Create data-driven tests using Excel test data
- [ ] Add email notifications for test results
- [ ] Implement retry logic for flaky elements
- [ ] Add more detailed logging

---

## Estimated Total Time: 35-45 minutes

## Key Success Indicators:
✅ Browser opens automatically
✅ Credentials entered correctly
✅ Login button clicked
✅ Login success verified
✅ Results written to Excel
✅ Screenshot captured

---

## Important Notes:

⚠️ **The provided XAML will NOT work out-of-the-box!**
   You MUST add the browser automation activities (Step "Add Browser Automation")

⚠️ **Selectors are environment-specific!**
   Each SAP system has different HTML structure - you must indicate YOUR elements

⚠️ **Security Warning:**
   Don't hardcode passwords in production. Use Orchestrator Assets or Windows Credential Manager

✅ **This is an Attended Bot:**
   It will run on your machine while you watch. You can see it working.

---

## Need Help?

1. Read SETUP_GUIDE.md for detailed instructions
2. Check Main.xaml for inline comments
3. Use UIPath Community Forum
4. Review UIPath 2024.10.1 documentation

---

**After completing this checklist, you'll have a working SAP login test automation that:**
- Logs into SAP automatically
- Verifies successful login
- Records results in Excel
- Captures screenshots
- Runs in attended mode (you can watch it work)