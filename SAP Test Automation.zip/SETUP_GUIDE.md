# SAP Login Test Automation - Setup Guide
## UIPath Studio 2024.10.1

## IMPORTANT: What You Need to Customize

The provided Main.xaml is a **working framework**, but you MUST customize these parts for your specific SAP environment:

### Critical Customizations Required:

1. **SAP URL** - Line in XAML where sapURL is assigned
2. **Browser Automation Block** - You must add the actual UI interactions
3. **Selectors** - Specific to your SAP login page

---

## Complete Setup Instructions

### Step 1: Create Project Structure

Create these folders in your UIPath project directory:

```
SAP_Login_Test_Automation/
├── Main.xaml (provided)
├── Data/
│   ├── Config.xlsx (optional - for storing credentials)
│   └── TestResults.xlsx (will be created automatically)
└── Screenshots/
```

### Step 2: Create the Config.xlsx File (Optional)

**Location:** `Data/Config.xlsx`

**Sheet Name:** Sheet1

**Structure:**
| Key | Value |
|-----|-------|
| SAP_URL | https://your-sap-system.company.com/login |
| Username | your_sap_username |
| Password | your_sap_password |
| Browser | Chrome |

**Note:** If you don't want to use Config file, you can keep the hardcoded values in the XAML (lines with "Hardcoded for Demo")

### Step 3: Import Main.xaml into UIPath

1. Open UIPath Studio 2024.10.1
2. Create New Process: `SAP_Login_Test_Automation`
3. Delete the default Main.xaml
4. Copy the provided Main.xaml into the project folder
5. Open the project in UIPath Studio

### Step 4: Customize the XAML - Add Browser Automation

The XAML has a **CommentOut** activity where you need to add the actual browser automation. Here's how:

#### A. Remove the CommentOut Block

1. In the XAML, find the activity: **"Comment - Browser Automation Block"**
2. Delete this CommentOut activity
3. In its place, add the following activities:

#### B. Add Use Application/Browser Activity

1. From Activities Panel, drag **"Use Application/Browser"** activity
2. Place it where the CommentOut was
3. Click **"Indicate Application to Automate"**
4. Open your SAP login page in browser
5. Select the browser window
6. Set these properties:
   - **URL:** `sapURL` (variable)
   - **Browser Type:** Chrome or Edge
   - **Open:** IfNotOpen

#### C. Inside the Browser Activity, Add These Steps:

**Step 1: Type Username**
1. Drag **"Type Into"** activity (Modern)
2. Click **"Indicate in Application"**
3. Point to the **Username field** on SAP login page
4. Properties:
   - Text: `userName`
   - Empty field: Checked
   - Click before typing: Checked

**Step 2: Type Password**
1. Drag another **"Type Into"** activity
2. Click **"Indicate in Application"**
3. Point to the **Password field**
4. Properties:
   - Text: `userPassword`
   - Empty field: Checked
   - **Secure Input: Checked** ✓

**Step 3: Click Login Button**
1. Drag **"Click"** activity
2. Click **"Indicate in Application"**
3. Point to the **Login button**

**Step 4: Verify Login Success**
1. Drag **"Check App State"** activity (Modern)
2. Click **"Indicate in Application"**
3. Point to an element that appears ONLY after successful login (like user menu, dashboard, or welcome message)
4. Set Timeout: 30000 (30 seconds)
5. In the **"Found"** branch:
   ```
   - Add Assign: status = "Pass"
   - Add Assign: loginSuccess = True
   - Add Log Message: "Login Successful"
   ```
6. In the **"Not Found"** branch:
   ```
   - Add Assign: status = "Fail"
   - Add Assign: errorMsg = "Home page not found after login"
   ```

**Step 5: Take Screenshot on Success**
1. Add **If** activity: `loginSuccess = True`
2. In **Then** branch, add **Take Screenshot** activity
   - Save to: `"Screenshots\" + testCaseID + "_Pass_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png"`
   - Output to: `screenshotPath`

**Step 6: Close Browser**
1. At the end of the Browser scope, add **Close Application** activity

### Step 5: Update Your SAP URL and Credentials

In the Main.xaml, find these three Assign activities and update them:

```xml
<!-- Line ~140: Update SAP URL -->
<Assign DisplayName="Assign - SAP URL (Hardcoded for Demo)">
  <Assign.Value>
    <InArgument x:TypeArguments="x:String">https://YOUR-ACTUAL-SAP-URL.com</InArgument>
  </Assign.Value>
</Assign>

<!-- Line ~148: Update Username -->
<Assign DisplayName="Assign - Username (Hardcoded for Demo)">
  <Assign.Value>
    <InArgument x:TypeArguments="x:String">your_actual_username</InArgument>
  </Assign.Value>
</Assign>

<!-- Line ~156: Update Password -->
<Assign DisplayName="Assign - Password (Hardcoded for Demo)">
  <Assign.Value>
    <InArgument x:TypeArguments="x:String">your_actual_password</InArgument>
  </Assign.Value>
</Assign>
```

### Step 6: Test Run

1. Create the **Data** folder in your project directory
2. Create the **Screenshots** folder
3. Press **F5** (Debug) or **Ctrl+F6** (Run)
4. Watch the automation execute
5. Check `Data/TestResults.xlsx` for results

---

## Understanding the XAML Structure

### Main Components:

1. **Variables Section (Lines 30-42)**
   - All test data variables
   - Status tracking
   - Timestamps

2. **Instructions Comment (Lines 44-56)**
   - Helpful setup reminders

3. **Test Initialization (Lines 57-68)**
   - Sets test case ID and name
   - Records start time

4. **Try-Catch Block (Lines 69-145)**
   - Main test execution
   - Error handling
   - This is where you add browser automation

5. **Results Preparation (Lines 146-160)**
   - Calculates duration
   - Builds data table with results

6. **Excel Reporting (Lines 161-175)**
   - Writes to TestResults.xlsx
   - Creates file if doesn't exist
   - Appends new results

7. **Completion Messages (Lines 176-186)**
   - Log final status
   - Show message box to user

---

## Selector Examples for SAP

When you indicate elements, UIPath will create selectors. Here are examples:

**Username Field Selector:**
```xml
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='INPUT' id='username' type='text' />
```

**Password Field Selector:**
```xml
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='INPUT' id='password' type='password' />
```

**Login Button Selector:**
```xml
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='BUTTON' aaname='Log In' />
```

**Note:** Your actual selectors will be different based on your SAP system's HTML structure.

---

## Running Multiple Test Cases

To test different scenarios, you can:

### Option 1: Modify Variables Before Each Run
Change `testCaseID`, `testCaseName`, and credentials

### Option 2: Create Multiple Test Case Workflows
1. Save Main.xaml as `TestCase_ValidLogin.xaml`
2. Save Main.xaml as `TestCase_InvalidLogin.xaml`
3. Modify credentials in each
4. Create a master workflow that invokes both

### Option 3: Data-Driven Testing
1. Create TestData.xlsx with multiple username/password combinations
2. Add **Read Range** activity to read test data
3. Add **For Each Row** to loop through test cases
4. Execute login for each row

---

## Excel Results File Format

**TestResults.xlsx** will contain:

| Test Case ID | Test Case Name | Execution Date | Start Time | End Time | Duration (sec) | Status | Error Message | Screenshot Path |
|--------------|----------------|----------------|------------|----------|----------------|--------|---------------|-----------------|
| TC001 | SAP Login Validation | 2024-12-15 | 09:30:15 | 09:30:45 | 30.00 | Pass | | Screenshots\TC001_Pass_20241215_093045.png |
| TC002 | Invalid Login Test | 2024-12-15 | 09:31:00 | 09:31:20 | 20.00 | Fail | Login failed | Screenshots\TC002_Fail_20241215_093120.png |

---

## Troubleshooting

### Issue 1: "Element not found"
**Solution:** 
- Check if selectors are correct
- Add longer timeout values
- Use UIPath's Selector Editor to validate

### Issue 2: "Excel file is locked"
**Solution:**
- Close Excel before running
- Use Excel Process Scope instead of Excel Application Scope

### Issue 3: "Browser doesn't open"
**Solution:**
- Check if URL is correct
- Ensure browser is installed
- Check network connectivity

### Issue 4: "Screenshots not saving"
**Solution:**
- Ensure Screenshots folder exists
- Check write permissions
- Verify path in Take Screenshot activity

---

## Advanced Enhancements

### 1. Add Config File Reader

Replace the hardcoded assigns with this:

```
Excel Application Scope: "Data\Config.xlsx"
  └── Read Range: Sheet="Sheet1", Output=dt_Config
  └── Assign: sapURL = dt_Config.Rows(0)(1).ToString
  └── Assign: userName = dt_Config.Rows(1)(1).ToString
  └── Assign: userPassword = dt_Config.Rows(2)(1).ToString
```

### 2. Add Retry Logic

Wrap the browser automation in a **Retry Scope** activity:
- Number of retries: 3
- Retry interval: 5 seconds

### 3. Add Email Notification

At the end of Main sequence:
```
Send Outlook Mail Message
  - To: "your.email@company.com"
  - Subject: "SAP Login Test - " + status
  - Body: Test results summary
  - Attachments: screenshotPath
```

### 4. Multiple Browser Support

Add a switch case based on browser type from config

---

## Security Best Practices

1. **Never hardcode passwords** in production
2. Use **Windows Credential Manager** for storing passwords
3. Use **Orchestrator Assets** for credentials
4. Enable **Secure Input** for password fields
5. Don't commit Config.xlsx to source control

---

## Next Steps

1. ✅ Set up folder structure
2. ✅ Import Main.xaml
3. ✅ Create Screenshots and Data folders
4. ⚠️ **CRITICAL:** Add the browser automation activities
5. ⚠️ Update SAP URL and credentials
6. ✅ Test run in Debug mode
7. ✅ Verify Excel results
8. ✅ Review screenshots

---

## Support

If you encounter issues:
1. Check UIPath documentation for 2024.10.1
2. Use UIPath Community Forum
3. Verify all packages are installed correctly
4. Check that Modern activities are being used

---

**Remember:** The provided XAML is a complete working framework, but the browser automation block MUST be customized for your specific SAP system. The selectors and elements will be unique to your environment.