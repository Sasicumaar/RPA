# SAP Login Test Automation - Visual Workflow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SAP LOGIN TEST AUTOMATION                        │
│                    UIPath Studio 2024.10.1                          │
│                    Attended Mode - Excel Reporting                  │
└─────────────────────────────────────────────────────────────────────┘

┌──────────────┐
│  START       │
└──────┬───────┘
       │
       ▼
┌────────────────────────────────────┐
│  Initialize Test Variables         │
│  • testCaseID = "TC001"            │
│  • testCaseName = "SAP Login Test" │
│  • startTime = Now                 │
│  • status = "Not Executed"         │
└────────┬───────────────────────────┘
         │
         ▼
┌────────────────────────────────────┐
│  Log: Starting Test Execution      │
└────────┬───────────────────────────┘
         │
         ▼
    ┌────────────────────────────────────┐
    │  TRY BLOCK - Main Test Execution   │
    └────┬───────────────────────────────┘
         │
         ▼
    ┌────────────────────────────────────┐
    │  Read Configuration                │
    │  ┌──────────────────────────────┐  │
    │  │ Option A: Hardcoded Values   │  │
    │  │ • sapURL                     │  │
    │  │ • userName                   │  │
    │  │ • userPassword               │  │
    │  └──────────────────────────────┘  │
    │  ┌──────────────────────────────┐  │
    │  │ Option B: From Config.xlsx   │  │
    │  │ • Read Excel Range           │  │
    │  │ • Extract URL, User, Pass    │  │
    │  └──────────────────────────────┘  │
    └────────┬───────────────────────────┘
             │
             ▼
    ┌────────────────────────────────────────────────┐
    │  ⚠️  CRITICAL: Browser Automation Block        │
    │  (YOU MUST ADD THIS - NOT IN BASE XAML)        │
    │                                                │
    │  Use Application/Browser                       │
    │  • URL: sapURL (from config)                   │
    │  • Browser: Chrome/Edge                        │
    │  • Open: IfNotOpen                             │
    │                                                │
    │  ┌──────────────────────────────────────────┐ │
    │  │  Inside Browser:                         │ │
    │  │                                          │ │
    │  │  1. Type Into - Username Field           │ │
    │  │     • Text: userName                     │ │
    │  │     • Empty field: Yes                   │ │
    │  │     • Click before typing: Yes           │ │
    │  │                                          │ │
    │  │  2. Type Into - Password Field           │ │
    │  │     • Text: userPassword                 │ │
    │  │     • Secure Input: ✓ Yes                │ │
    │  │     • Empty field: Yes                   │ │
    │  │                                          │ │
    │  │  3. Click - Login Button                 │ │
    │  │     • Click Type: Single                 │ │
    │  │                                          │ │
    │  │  4. Check App State - Home Page Element  │ │
    │  │     • Timeout: 30 seconds                │ │
    │  │     │                                    │ │
    │  │     ├─ Found? ────────────────┐          │ │
    │  │     │                         │          │ │
    │  │     │    ┌────────────────────▼────┐     │ │
    │  │     │    │ status = "Pass"         │     │ │
    │  │     │    │ loginSuccess = True     │     │ │
    │  │     │    │ Log: "Login Successful" │     │ │
    │  │     │    └─────────────────────────┘     │ │
    │  │     │                                    │ │
    │  │     └─ Not Found? ─────────────┐         │ │
    │  │                                │         │ │
    │  │    ┌───────────────────────────▼──────┐  │ │
    │  │    │ status = "Fail"                  │  │ │
    │  │    │ errorMsg = "Home page not found" │  │ │
    │  │    │ Take Screenshot (Failure)        │  │ │
    │  │    └──────────────────────────────────┘  │ │
    │  │                                          │ │
    │  │  5. IF loginSuccess = True               │ │
    │  │     • Take Screenshot (Success)          │ │
    │  │     • Save to Screenshots folder         │ │
    │  │                                          │ │
    │  │  6. Close Application                    │ │
    │  └──────────────────────────────────────────┘ │
    └────────┬───────────────────────────────────────┘
             │
             ├──────────────────────────────────────┐
             │                                      │
             │ SUCCESS                         EXCEPTION
             │                                      │
             ▼                                      ▼
    ┌─────────────────────┐          ┌──────────────────────────┐
    │ Log: Test Complete  │          │  CATCH BLOCK             │
    └──────┬──────────────┘          │  • status = "Fail"       │
           │                         │  • errorMsg = exception  │
           │                         │  • Log Error             │
           │                         │  • Try Take Screenshot   │
           │                         └──────┬───────────────────┘
           │                                │
           └────────────┬───────────────────┘
                        │
                        ▼
        ┌───────────────────────────────────┐
        │  Calculate Test Metrics           │
        │  • endTime = Now                  │
        │  • duration = (end - start)       │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────────────────────────┐
        │  Build Results DataTable          │
        │  ┌─────────────────────────────┐  │
        │  │ Columns:                    │  │
        │  │ • Test Case ID              │  │
        │  │ • Test Case Name            │  │
        │  │ • Execution Date            │  │
        │  │ • Start Time                │  │
        │  │ • End Time                  │  │
        │  │ • Duration (sec)            │  │
        │  │ • Status (Pass/Fail)        │  │
        │  │ • Error Message             │  │
        │  │ • Screenshot Path           │  │
        │  └─────────────────────────────┘  │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────────────────────────┐
        │  Add Current Test Results Row     │
        │  to DataTable                     │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────────────────────────┐
        │  Excel Application Scope          │
        │  File: Data\TestResults.xlsx      │
        │  ┌─────────────────────────────┐  │
        │  │  Append Range Activity      │  │
        │  │  • Sheet: "Results"         │  │
        │  │  • DataTable: dt_Results    │  │
        │  │  • Add Headers: Yes         │  │
        │  └─────────────────────────────┘  │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────────────────────────┐
        │  Log: Test Execution Complete     │
        │  "Status: [Pass/Fail]"            │
        │  "Duration: [X.XX] seconds"       │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────────────────────────┐
        │  Message Box                      │
        │  Display Final Results to User    │
        │  • Test Case Name                 │
        │  • Status                         │
        │  • Duration                       │
        │  • Error Message (if any)         │
        └───────┬───────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │   END         │
        └───────────────┘

═══════════════════════════════════════════════════════════════════

OUTPUTS GENERATED:

📁 Data/TestResults.xlsx
┌──────────────┬──────────────┬────────────┬────────────┬──────────┐
│ Test Case ID │ Status       │ Start Time │ End Time   │ Duration │
├──────────────┼──────────────┼────────────┼────────────┼──────────┤
│ TC001        │ Pass         │ 09:30:15   │ 09:30:45   │ 30.00s   │
│ TC002        │ Fail         │ 09:31:00   │ 09:31:20   │ 20.00s   │
└──────────────┴──────────────┴────────────┴────────────┴──────────┘

📁 Screenshots/
├── TC001_Pass_20241215_093045.png
├── TC001_Fail_20241215_093120.png
└── TC001_Error_20241215_093200.png

═══════════════════════════════════════════════════════════════════

KEY DECISION POINTS:

🔸 Line 140-156: Configuration Source
   → Hardcoded OR Config.xlsx

🔸 Browser Automation Block (YOUR CUSTOMIZATION)
   → Add Use Application/Browser
   → Indicate Username, Password, Login button
   → Verify home page element

🔸 Line 70-145: Try-Catch
   → Success: Status = "Pass"
   → Failure: Status = "Fail", capture error

🔸 Line 161-175: Excel Reporting
   → Append results to TestResults.xlsx
   → Creates file if doesn't exist

═══════════════════════════════════════════════════════════════════

VARIABLE FLOW:

testCaseID ──────────────────────────┐
testCaseName ────────────────────────┤
startTime ───────────────────────────┤
sapURL (from config) ────────────────┤
userName (from config) ──────────────┤──▶ dt_Results ──▶ Excel
userPassword (from config) ──────────┤
status (Pass/Fail) ──────────────────┤
errorMsg ────────────────────────────┤
duration ────────────────────────────┤
screenshotPath ──────────────────────┘

═══════════════════════════════════════════════════════════════════
```

## Critical Path Visualization

```
HAPPY PATH (Success):
START → Init → Config → Browser → Username → Password → Click → 
Verify Success → Screenshot → Close → Calculate → Excel → END ✅

ERROR PATH (Failure):
START → Init → Config → Browser → ... → EXCEPTION → 
Catch → Set Fail → Screenshot → Calculate → Excel → END ❌

LOGIN FAILED PATH:
START → Init → Config → Browser → Username → Password → Click → 
Home Page Not Found → Set Fail → Screenshot → Close → Calculate → 
Excel → END ⚠️
```

## Time Estimates

```
┌────────────────────────┬──────────────┐
│ Activity               │ Duration     │
├────────────────────────┼──────────────┤
│ Initialization         │ < 1 second   │
│ Read Config            │ 1-2 seconds  │
│ Open Browser           │ 3-5 seconds  │
│ Type Credentials       │ 1-2 seconds  │
│ Click Login            │ < 1 second   │
│ Wait for Home Page     │ 5-30 seconds │
│ Screenshot             │ 1-2 seconds  │
│ Write to Excel         │ 2-3 seconds  │
│ Total (Typical)        │ 15-45 sec    │
└────────────────────────┴──────────────┘
```

## Error Handling Layers

```
Layer 1: Try-Catch (Main Execution)
         └─ Catches all exceptions during browser automation

Layer 2: Check App State (Login Verification)
         └─ Handles cases where login appears successful but isn't

Layer 3: Nested Try-Catch (Screenshot)
         └─ Prevents screenshot failures from breaking the flow

Layer 4: Excel Error Handling
         └─ Built into Excel Application Scope
```