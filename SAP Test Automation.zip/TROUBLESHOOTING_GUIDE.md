# Troubleshooting Guide - SAP Login Test Automation

## Common Issues and Solutions

---

## 1. XAML Import/Loading Issues

### Issue: "Cannot open Main.xaml" or "XAML parse error"
**Symptoms:**
- Error when trying to open XAML file
- Project won't load
- Compilation errors

**Solutions:**
1. ✅ Verify UIPath Studio version is 2024.10.1 or later
2. ✅ Check that all required packages are installed:
   ```
   - UiPath.Excel.Activities (v2.24.x+)
   - UiPath.UIAutomation.Activities
   - UiPath.System.Activities
   ```
3. ✅ Ensure XAML file is in the correct project directory
4. ✅ Try creating a new project and importing the XAML

**Quick Fix:**
```
1. Create new Process project
2. Delete default Main.xaml
3. Copy provided Main.xaml into project folder
4. Open UIPath Studio
5. Refresh project
```

---

## 2. Browser Automation Issues

### Issue: Browser doesn't open
**Symptoms:**
- No browser window appears
- Timeout error
- "Application not found" error

**Solutions:**
1. ✅ Verify SAP URL is correct and accessible
   ```
   Test in browser manually first:
   - Open Chrome/Edge
   - Navigate to SAP URL
   - Verify page loads
   ```

2. ✅ Check browser installation
   ```
   - Chrome: Must be installed
   - Edge: Built-in to Windows
   - Firefox: Requires separate WebDriver
   ```

3. ✅ Update browser automation:
   ```
   Use Application/Browser properties:
   - URL: sapURL (variable, not hardcoded string)
   - Browser Type: Chrome or Edge
   - Open: IfNotOpen
   ```

4. ✅ Check network connectivity
   ```
   ping your-sap-domain.com
   ```

**Quick Fix:**
```
1. Open browser manually
2. Navigate to SAP URL
3. Re-indicate application in UIPath
4. Use "Attach Browser" instead of "Use Application/Browser"
```

---

### Issue: Elements not found (Username, Password, Login button)
**Symptoms:**
- "Selector not found" error
- "UI element not found" exception
- Automation clicks wrong element

**Solutions:**
1. ✅ Use UI Explorer to validate selectors
   ```
   Steps:
   - Open UI Explorer (Tools menu)
   - Attach to SAP browser window
   - Indicate username field
   - Examine selector
   - Copy reliable attributes (id, name, class)
   ```

2. ✅ Increase timeout values
   ```
   In each activity:
   - Timeout: 30000 (30 seconds)
   - Wait For Ready: Complete
   ```

3. ✅ Re-indicate elements
   ```
   - Delete existing Type Into activities
   - Add new ones
   - Use "Indicate in Application"
   - Point to correct elements
   ```

4. ✅ Use alternative selector strategies
   ```
   If dynamic IDs:
   - Use aaname (Accessible Name)
   - Use class + role
   - Use relative positioning
   - Use Anchor Base activity
   ```

**Example Reliable Selectors:**
```xml
<!-- Username Field -->
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='INPUT' aaname='Username' type='text' />

<!-- Password Field -->
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='INPUT' aaname='Password' type='password' />

<!-- Login Button -->
<html app='chrome.exe' title='SAP Login' />
<webctrl tag='BUTTON' aaname='Log In' class='login-button' />
```

**Quick Fix:**
```
1. Add "Wait Element Vanish" before Type Into
   Wait for loading spinner to disappear
2. Add 1-2 second delay between actions
3. Use "Click Before Typing" option
4. Enable "Empty Field" option
```

---

### Issue: Check App State not detecting home page
**Symptoms:**
- Always goes to "Not Found" branch
- Login appears successful but test fails
- "Element not found" after login

**Solutions:**
1. ✅ Choose better home page indicator
   ```
   Good indicators:
   - User profile menu (top right)
   - Logout button
   - Dashboard title
   - Welcome message with username
   
   Bad indicators:
   - Company logo (exists on login page too)
   - Generic menu items
   - Footer elements
   ```

2. ✅ Increase Check App State timeout
   ```
   Properties:
   - Timeout: 45000 (45 seconds)
   - Some SAP systems are slow to load
   ```

3. ✅ Add multiple verification points
   ```
   Use "Check App State" twice:
   - First: Check if login page is gone
   - Second: Check if home page appeared
   ```

**Quick Fix:**
```
Replace Check App State with:
1. Element Exists activity
2. If Element Exists = True
   Then: Login successful
   Else: Login failed
```

---

## 3. Excel and File Issues

### Issue: "Excel file is locked" or "Cannot write to file"
**Symptoms:**
- Error when writing results
- "File in use by another process"
- Results not saved

**Solutions:**
1. ✅ Close Excel before running
   ```
   - Close TestResults.xlsx
   - Close Config.xlsx
   - Check Task Manager for Excel processes
   ```

2. ✅ Use Excel Process Scope (Modern)
   ```
   Instead of: Excel Application Scope
   Use: Excel Process Scope
   Benefits: Better handling, auto-close
   ```

3. ✅ Check file permissions
   ```
   Right-click file > Properties > Security
   Ensure you have Write permissions
   ```

**Quick Fix:**
```
Add to workflow before Excel operations:
Kill Process: "EXCEL.EXE"
Wait: 2 seconds
Then: Excel Application Scope
```

---

### Issue: "File not found" - TestResults.xlsx doesn't exist
**Symptoms:**
- First run fails
- "Path not found" error
- Excel scope fails

**Solutions:**
1. ✅ Create Data folder manually
   ```
   C:\Users\[YourUser]\Documents\UiPath\SAP_Login_Test_Automation\Data\
   ```

2. ✅ Add file creation logic
   ```
   Before Excel Application Scope:
   
   Path Exists: "Data\TestResults.xlsx"
   Output: fileExists
   
   If fileExists = False
   Then:
     Excel Create Table
     - File: "Data\TestResults.xlsx"
     - Table Name: "Results"
     - Add headers
   ```

3. ✅ Use relative paths
   ```
   Good: "Data\TestResults.xlsx"
   Bad: "C:\Full\Path\To\File.xlsx"
   ```

**Quick Fix:**
```
1. Manually create Data folder
2. Manually create blank Excel file: TestResults.xlsx
3. Add these headers in Row 1:
   Test Case ID | Test Case Name | Execution Date | 
   Start Time | End Time | Duration (sec) | Status | 
   Error Message | Screenshot Path
```

---

### Issue: Excel columns misaligned or data in wrong cells
**Symptoms:**
- Results appear in wrong columns
- Headers missing
- Data overwritten

**Solutions:**
1. ✅ Verify DataTable structure matches Excel
   ```
   Build Data Table columns (in order):
   1. Test Case ID
   2. Test Case Name
   3. Execution Date
   4. Start Time
   5. End Time
   6. Duration (sec)
   7. Status
   8. Error Message
   9. Screenshot Path
   ```

2. ✅ Use "Add Headers" option
   ```
   Excel Append Range:
   - AddHeaders: True (for first run)
   - AddHeaders: False (for subsequent runs)
   ```

3. ✅ Clear existing data if needed
   ```
   Before Append Range:
   Read Range > Check if empty > Clear Range if needed
   ```

**Quick Fix:**
```
Delete TestResults.xlsx
Let automation create fresh file
First run will add headers automatically
```

---

## 4. Screenshot Issues

### Issue: Screenshots not captured or not found
**Symptoms:**
- screenshotPath is empty
- Screenshots folder empty
- "Path not found" error

**Solutions:**
1. ✅ Create Screenshots folder
   ```
   Manually create:
   C:\Users\[YourUser]\Documents\UiPath\SAP_Login_Test_Automation\Screenshots\
   ```

2. ✅ Verify Take Screenshot settings
   ```
   Properties:
   - Path: "Screenshots\" + testCaseID + "_" + 
           DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png"
   - Output: screenshotPath
   ```

3. ✅ Check file permissions
   ```
   Ensure write permission on Screenshots folder
   ```

4. ✅ Use Try-Catch around screenshot
   ```
   Already implemented in provided XAML
   If screenshot fails, won't break workflow
   ```

**Quick Fix:**
```
1. Create Screenshots folder manually
2. Test Take Screenshot activity separately:
   - Save to: "C:\Temp\test.png"
   - If works: folder permission issue
   - If fails: UIPath screenshot issue
```

---

## 5. Variable and Data Type Issues

### Issue: "Type conversion error" or "Cannot convert string to DateTime"
**Symptoms:**
- Compilation errors
- Runtime type mismatch
- Variable assignment fails

**Solutions:**
1. ✅ Verify variable types
   ```
   Variables panel:
   - testCaseID: String
   - startTime: DateTime
   - duration: Double
   - loginSuccess: Boolean
   - dt_Results: DataTable
   ```

2. ✅ Use correct conversion methods
   ```
   String to DateTime: DateTime.Parse(stringValue)
   String to Double: Double.Parse(stringValue)
   DateTime to String: dateValue.ToString("format")
   ```

3. ✅ Check DataTable column types
   ```
   Build Data Table:
   All columns should be String type for simplicity
   ```

**Quick Fix:**
```
In Add Data Row activity, ensure all values are strings:
{
  testCaseID,
  testCaseName,
  DateTime.Now.ToString("yyyy-MM-dd"),
  startTime.ToString("HH:mm:ss"),
  endTime.ToString("HH:mm:ss"),
  duration.ToString("F2"),
  status,
  errorMsg,
  screenshotPath
}
```

---

## 6. Performance and Timeout Issues

### Issue: Test execution very slow or times out
**Symptoms:**
- Takes > 2 minutes to complete
- Frequent timeout errors
- Browser unresponsive

**Solutions:**
1. ✅ Optimize selector delays
   ```
   Remove unnecessary "Delay" activities
   Use "Wait For Ready: Complete" instead
   ```

2. ✅ Increase timeout for slow pages
   ```
   Check App State:
   - Timeout: 60000 (1 minute) for very slow SAP
   ```

3. ✅ Check network speed
   ```
   Run speed test
   Verify VPN not causing delays
   ```

4. ✅ Reduce screenshot resolution
   ```
   Take Screenshot:
   - Use lower quality/resolution if available
   ```

**Quick Fix:**
```
Add "Wait For Ready" activities:
- After Type Into: WaitForReady.Complete
- After Click: WaitForReady.Interactive
- Before Check App State: WaitForReady.Complete
```

---

## 7. Credential and Security Issues

### Issue: Password not entered correctly or visible in logs
**Symptoms:**
- Login fails with correct password
- Password visible in plain text
- Security audit flags

**Solutions:**
1. ✅ Enable Secure Input for password
   ```
   Type Into (Password field):
   - SecureInput: Checked ✓
   - This masks password in logs
   ```

2. ✅ Use SecureString type
   ```
   Variable: userPassword
   Type: System.Security.SecureString
   ```

3. ✅ Never log passwords
   ```
   In Log Message activities:
   - Don't include userPassword variable
   - Use: "Logging in with username: " + userName
   - NOT: "Password: " + userPassword
   ```

4. ✅ Use Orchestrator Assets (Production)
   ```
   Instead of Config.xlsx:
   Get Credential: "SAP_Login_Creds"
   Output: username, password (SecureString)
   ```

**Quick Fix:**
```
1. Open Type Into activity for password
2. Check "Secure Input" checkbox
3. Verify "Private" checkbox is checked
4. Remove any Log Message that shows password
```

---

## 8. Multiple Runs and State Issues

### Issue: Second run fails even though first run succeeded
**Symptoms:**
- First execution: Pass
- Subsequent executions: Fail
- "Element already exists" error

**Solutions:**
1. ✅ Ensure browser closes completely
   ```
   At end of workflow:
   - Close Application
   - OR Kill Process: "chrome.exe"
   ```

2. ✅ Clear browser cache/cookies
   ```
   Before Use Application/Browser:
   - Private Session: True
   - OR use Incognito mode
   ```

3. ✅ Add cleanup logic
   ```
   Finally block in Try-Catch:
   - Close all open browsers
   - Clear variables
   ```

**Quick Fix:**
```
Add at end of Main sequence:
Kill Process: "chrome.exe"
Wait: 2 seconds
This ensures clean state for next run
```

---

## 9. SAP-Specific Issues

### Issue: SAP GUI scripting disabled
**Symptoms:**
- Cannot automate SAP GUI client
- "Scripting not enabled" error
- Activities fail on SAP GUI

**Solutions:**
1. ✅ Enable SAP GUI scripting
   ```
   In SAP Logon:
   - Options > Accessibility & Scripting
   - Check "Enable Scripting"
   ```

2. ✅ Use web-based SAP instead
   ```
   SAP Fiori / SAP WebGUI:
   - Easier to automate
   - Better selector stability
   - No special configuration needed
   ```

3. ✅ Install SAP GUI Scripting DLL
   ```
   May need administrative rights
   Contact IT department
   ```

**Quick Fix:**
```
Switch to SAP web interface:
- Use browser-based automation
- Avoids SAP GUI scripting issues
- More reliable selectors
```

---

## 10. Debugging Tips

### General Debugging Strategy

1. **Use Debug Mode (F5)**
   ```
   - Run step-by-step
   - Inspect variables after each activity
   - See exact point of failure
   ```

2. **Add Log Messages liberally**
   ```
   Before each major step:
   Log Message: "About to [action]"
   After each step:
   Log Message: "[Action] completed successfully"
   ```

3. **Use Breakpoints**
   ```
   - Click left margin to add breakpoint
   - Execution pauses at breakpoint
   - Inspect Variables panel
   ```

4. **Test activities individually**
   ```
   - Comment out entire workflow
   - Test one activity at a time
   - Un-comment once confirmed working
   ```

5. **Check Output panel**
   ```
   - View > Output
   - Shows all log messages
   - Shows error details
   - Shows execution timestamps
   ```

---

## Error Code Reference

| Error Code | Meaning | Solution |
|------------|---------|----------|
| Selector not found | UI element not detected | Re-indicate element, increase timeout |
| Timeout exception | Activity took too long | Increase timeout value |
| File not found | Path incorrect or file missing | Create file/folder, check path |
| Type conversion | Data type mismatch | Use .ToString() or Parse() |
| Null reference | Variable not initialized | Initialize variable before use |
| Access denied | Permission issue | Check file/folder permissions |

---

## Getting Additional Help

1. **UIPath Community Forum**
   - forum.uipath.com
   - Search for similar issues
   - Post your error message

2. **UIPath Documentation**
   - docs.uipath.com
   - Check activity documentation
   - Review best practices

3. **UIPath Academy**
   - academy.uipath.com
   - Free training courses
   - Certification programs

4. **Local UIPath User Groups**
   - meetup.com
   - Search for "UIPath" in your city

---

## Preventive Maintenance

### Weekly Checks:
- [ ] Verify SAP URL still accessible
- [ ] Check if SAP UI changed
- [ ] Review TestResults.xlsx
- [ ] Clean Screenshots folder (keep last 100)

### Monthly Checks:
- [ ] Update UIPath packages
- [ ] Update browser version
- [ ] Review and update selectors
- [ ] Archive old test results

### Before Production:
- [ ] Test on multiple machines
- [ ] Verify on clean Windows installation
- [ ] Load test with multiple concurrent runs
- [ ] Security audit (no exposed credentials)

---

## Still Having Issues?

**Create a support package:**

1. Export project.json
2. Include Main.xaml
3. Include error screenshots
4. Include Output panel text
5. Include system information:
   - UIPath version
   - Windows version
   - Browser version
   - SAP URL (redacted)

**Email or post to forum with:**
- Detailed error description
- Steps to reproduce
- Expected vs actual behavior
- Support package attachment

---

Remember: Most issues are related to:
1. ❌ Missing browser automation (you must add this!)
2. ❌ Incorrect selectors
3. ❌ Missing folders/files
4. ❌ Closed Excel files

Fix these four items first before seeking help!