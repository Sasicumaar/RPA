# Sample Test Scenarios for SAP Login Automation

## Test Case Catalog

### Test Case 1: Valid Login
**Test ID:** TC001  
**Description:** Verify successful login with valid credentials  
**Priority:** High  
**Expected Result:** User should be redirected to SAP home page

**Test Data:**
- URL: https://your-sap-url.com
- Username: valid_user
- Password: valid_password

**Steps:**
1. Open SAP login page
2. Enter valid username
3. Enter valid password
4. Click Login button
5. Verify home page is displayed

**Expected Status:** Pass  
**Screenshot:** TC001_Pass_[timestamp].png

---

### Test Case 2: Invalid Username
**Test ID:** TC002  
**Description:** Verify error message with invalid username  
**Priority:** High  
**Expected Result:** Error message displayed, login fails

**Test Data:**
- URL: https://your-sap-url.com
- Username: invalid_user_12345
- Password: valid_password

**Steps:**
1. Open SAP login page
2. Enter invalid username
3. Enter valid password
4. Click Login button
5. Verify error message displayed

**Expected Status:** Fail  
**Expected Error:** "Invalid username or password"

---

### Test Case 3: Invalid Password
**Test ID:** TC003  
**Description:** Verify error message with invalid password  
**Priority:** High  
**Expected Result:** Error message displayed, login fails

**Test Data:**
- URL: https://your-sap-url.com
- Username: valid_user
- Password: wrong_password

**Steps:**
1. Open SAP login page
2. Enter valid username
3. Enter invalid password
4. Click Login button
5. Verify error message displayed

**Expected Status:** Fail  
**Expected Error:** "Invalid username or password"

---

### Test Case 4: Empty Credentials
**Test ID:** TC004  
**Description:** Verify validation when leaving fields empty  
**Priority:** Medium  
**Expected Result:** Validation error, cannot submit

**Test Data:**
- URL: https://your-sap-url.com
- Username: (empty)
- Password: (empty)

**Steps:**
1. Open SAP login page
2. Leave username empty
3. Leave password empty
4. Click Login button
5. Verify validation error

**Expected Status:** Fail  
**Expected Error:** "Username and password required"

---

### Test Case 5: SQL Injection Attempt
**Test ID:** TC005  
**Description:** Verify security against SQL injection  
**Priority:** High  
**Expected Result:** Login fails, no security breach

**Test Data:**
- URL: https://your-sap-url.com
- Username: admin' OR '1'='1
- Password: password' OR '1'='1

**Steps:**
1. Open SAP login page
2. Enter SQL injection string in username
3. Enter SQL injection string in password
4. Click Login button
5. Verify login is rejected

**Expected Status:** Fail  
**Expected Error:** "Invalid credentials"

---

## Creating Data-Driven Tests

### Option 1: TestData.xlsx Format

Create a file: `Data/TestData.xlsx`

**Sheet: LoginTests**

| TestCaseID | TestCaseName | URL | Username | Password | ExpectedStatus | ExpectedError |
|------------|--------------|-----|----------|----------|----------------|---------------|
| TC001 | Valid Login | https://sap.company.com | user1 | Pass@123 | Pass | |
| TC002 | Invalid User | https://sap.company.com | invalid_user | Pass@123 | Fail | Invalid credentials |
| TC003 | Invalid Pass | https://sap.company.com | user1 | wrong_pass | Fail | Invalid credentials |
| TC004 | Empty Fields | https://sap.company.com | | | Fail | Fields required |
| TC005 | Special Chars | https://sap.company.com | user@123 | P@ss!123 | Pass | |

### Option 2: Using Excel in UIPath

To read test data and loop through tests:

```
┌─ Read Range
│  File: "Data\TestData.xlsx"
│  Sheet: "LoginTests"
│  Output: dt_TestData
│
└─ For Each Row in dt_TestData
   │
   ├─ Assign: testCaseID = row("TestCaseID").ToString
   ├─ Assign: testCaseName = row("TestCaseName").ToString
   ├─ Assign: sapURL = row("URL").ToString
   ├─ Assign: userName = row("Username").ToString
   ├─ Assign: userPassword = row("Password").ToString
   │
   ├─ Execute Login Test (same browser automation as Main.xaml)
   │
   └─ Write results to TestResults.xlsx
```

---

## Sample Project Structure

```
SAP_Login_Test_Automation/
│
├── Main.xaml                          # Main test executor
├── TestCase_ValidLogin.xaml           # Specific test case
├── TestCase_InvalidLogin.xaml         # Specific test case
│
├── Data/
│   ├── Config.xlsx                    # Configuration file
│   ├── TestData.xlsx                  # Test scenarios data
│   └── TestResults.xlsx               # Output results
│
├── Screenshots/
│   ├── TC001_Pass_20241215_093045.png
│   ├── TC002_Fail_20241215_093120.png
│   └── TC003_Fail_20241215_093200.png
│
└── Documentation/
    ├── SETUP_GUIDE.md
    ├── QUICK_START_CHECKLIST.md
    └── TEST_SCENARIOS.md (this file)
```

---

## Creating Multiple Test Case Files

### Method 1: Duplicate Main.xaml

1. Copy Main.xaml → TestCase_ValidLogin.xaml
2. Update test case ID and name
3. Set appropriate credentials
4. Run each file individually

### Method 2: Master Test Runner

Create `TestRunner.xaml`:

```
Sequence: Test Runner
│
├── For Each file in Directory.GetFiles(".\", "TestCase_*.xaml")
│   │
│   ├── Log: "Executing " + file
│   │
│   ├── Invoke Workflow File
│   │   WorkflowPath: file
│   │
│   └── Log: "Completed " + file
│
└── Log: "All tests completed"
```

---

## Advanced Test Scenarios

### Scenario 1: Session Timeout Test
**Purpose:** Verify session timeout after inactivity

**Steps:**
1. Login successfully
2. Wait 30 minutes (use Delay activity)
3. Try to navigate to a page
4. Verify session timeout message

### Scenario 2: Concurrent Login Test
**Purpose:** Verify behavior when same user logs in from multiple sessions

**Steps:**
1. Login from Bot 1
2. Login same user from Bot 2
3. Verify first session is terminated

### Scenario 3: Password Change Test
**Purpose:** Verify forced password change on first login

**Steps:**
1. Login with temporary password
2. Verify password change prompt
3. Enter new password
4. Confirm new password
5. Verify login successful

### Scenario 4: Multi-Factor Authentication
**Purpose:** Test MFA if enabled

**Steps:**
1. Enter username and password
2. Wait for MFA prompt
3. Use Image Recognition for QR code
4. Enter OTP (if available)

---

## Test Execution Schedule

### Daily Regression Suite
- TC001: Valid Login
- TC002: Invalid Username
- TC003: Invalid Password

### Weekly Full Suite
- All test cases (TC001-TC005)
- Performance metrics
- Screenshot comparison

### Monthly Security Suite
- SQL Injection tests
- XSS tests
- Session management tests

---

## Expected Results Summary

| Test Case | Expected Duration | Expected Status | Screenshot Required |
|-----------|------------------|-----------------|---------------------|
| TC001 | 20-30 seconds | Pass | Yes |
| TC002 | 15-20 seconds | Fail | Yes |
| TC003 | 15-20 seconds | Fail | Yes |
| TC004 | 10-15 seconds | Fail | Yes |
| TC005 | 15-20 seconds | Fail | Yes |

---

## Results Analysis Template

After running tests, analyze results using this template:

```
Test Execution Summary
Date: [Date]
Environment: [SAP Environment]
Tester: [Automation Bot]

Total Tests: 5
Passed: X
Failed: Y
Success Rate: Z%

Failed Test Analysis:
- TC00X: [Reason for failure]
- TC00Y: [Reason for failure]

Performance Metrics:
- Average execution time: X seconds
- Slowest test: TC00X (Y seconds)
- Fastest test: TC00Y (Z seconds)

Screenshots Captured: X
Errors Logged: Y

Recommendations:
1. [Action item 1]
2. [Action item 2]
```

---

## Customization for Your Environment

### Step 1: Identify Your Test Scenarios
List the specific scenarios relevant to your SAP system

### Step 2: Create TestData.xlsx
Populate with your actual test data

### Step 3: Update Expected Results
Modify expected errors based on your SAP system's messages

### Step 4: Add Environment-Specific Tests
Include tests for:
- Your company's specific workflows
- Custom SAP modules
- Integration with other systems

---

## Sample Config.xlsx Structure

**Sheet: Config**
| Key | Value | Description |
|-----|-------|-------------|
| SAP_URL | https://sap.company.com | Production SAP URL |
| SAP_URL_DEV | https://dev-sap.company.com | Development SAP URL |
| Browser | Chrome | Default browser |
| Timeout | 30000 | Default timeout (ms) |
| RetryCount | 3 | Number of retries on failure |

**Sheet: TestUsers**
| UserType | Username | Password | Role |
|----------|----------|----------|------|
| Admin | admin_user | Pass@123 | Administrator |
| StandardUser | std_user | Pass@456 | Standard |
| ReadOnly | ro_user | Pass@789 | Read Only |
| InvalidUser | inv_user | WrongPass | Invalid |

---

## Tips for Better Test Coverage

1. **Test Positive and Negative Scenarios**
   - Both successful and failed logins

2. **Test Boundary Conditions**
   - Maximum password length
   - Special characters
   - Unicode characters

3. **Test Performance**
   - Login time under load
   - Response time variations

4. **Test Security**
   - Injection attacks
   - Session security
   - Password masking

5. **Test Accessibility**
   - Keyboard navigation
   - Screen reader compatibility

---

## Common SAP Login Error Messages

- "Invalid username or password"
- "Account locked due to multiple failed attempts"
- "Password expired, please change"
- "User not authorized for this system"
- "Maximum number of users reached"
- "System is in maintenance mode"

Document your system's specific messages and update test cases accordingly.

---

## Next Steps After Basic Testing

1. ✅ Implement all 5 basic test cases
2. ✅ Create data-driven test framework
3. ✅ Add performance monitoring
4. ✅ Implement email notifications
5. ✅ Create dashboard for results visualization
6. ✅ Schedule automated runs
7. ✅ Integrate with CI/CD pipeline (if applicable)

---

**Remember:** These are templates. Customize them based on your specific SAP environment, security requirements, and business needs.