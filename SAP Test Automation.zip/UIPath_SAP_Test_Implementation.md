# UIPath SAP Login Test Automation - Implementation Guide
## Version: UIPath Studio 2024.10.1

### Activity-by-Activity Workflow

#### MAIN.XAML - Complete Structure

```
SEQUENCE: Main
│
├── COMMENT: "Initialize Test Parameters"
│
├── ASSIGN: testCaseID = "TC001"
├── ASSIGN: testCaseName = "SAP Login Validation"
├── ASSIGN: startTime = DateTime.Now
├── LOG MESSAGE: "Starting test: " + testCaseName
│
├── TRY-CATCH
│   │
│   ├── TRY:
│   │   │
│   │   ├── COMMENT: "Read Configuration"
│   │   │
│   │   ├── EXCEL PROCESS SCOPE
│   │   │   Properties:
│   │   │   - File Path: "Config\Config.xlsx"
│   │   │   - Sheet Name: "Sheet1"
│   │   │   - Reference As: "ConfigData"
│   │   │   
│   │   │   Body:
│   │   │   ├── READ RANGE (Modern)
│   │   │   │   - Range: "A1:B10"
│   │   │   │   - Output: dt_Config
│   │   │   │
│   │   │   └── MULTIPLE ASSIGN
│   │   │       - sapURL = dt_Config.Rows(0)(1).ToString
│   │   │       - userName = dt_Config.Rows(1)(1).ToString
│   │   │       - userPassword = dt_Config.Rows(2)(1).ToString
│   │   │
│   │   ├── COMMENT: "Execute SAP Login"
│   │   │
│   │   ├── USE APPLICATION/BROWSER (Modern)
│   │   │   Properties:
│   │   │   - URL: sapURL
│   │   │   - Browser Type: Chrome
│   │   │   - Private Session: False
│   │   │   - Open: IfNotOpen
│   │   │   
│   │   │   Body - Do:
│   │   │   │
│   │   │   ├── COMMENT: "Wait for page load"
│   │   │   │
│   │   │   ├── CHECK APP STATE (Modern) - Verify page loaded
│   │   │   │   - Target: Login page element
│   │   │   │   - Timeout: 30000
│   │   │   │   
│   │   │   │   Found:
│   │   │   │   └── LOG MESSAGE: "Login page loaded successfully"
│   │   │   │   
│   │   │   │   Not Found:
│   │   │   │   └── THROW: New Exception("Login page not loaded")
│   │   │   │
│   │   │   ├── TYPE INTO (Modern)
│   │   │   │   Properties:
│   │   │   │   - Target: Username field (use Indicate in Application)
│   │   │   │   - Text: userName
│   │   │   │   - Empty Field: Yes
│   │   │   │   - Click Before Typing: Yes
│   │   │   │   - Delay Between Keys: 30ms
│   │   │   │
│   │   │   ├── TYPE INTO (Modern)
│   │   │   │   Properties:
│   │   │   │   - Target: Password field
│   │   │   │   - Text: userPassword
│   │   │   │   - Empty Field: Yes
│   │   │   │   - Secure Input: Checked ✓
│   │   │   │   - Click Before Typing: Yes
│   │   │   │
│   │   │   ├── CLICK (Modern)
│   │   │   │   Properties:
│   │   │   │   - Target: Login button
│   │   │   │   - Click Type: Single
│   │   │   │   - Mouse Button: Left
│   │   │   │
│   │   │   ├── COMMENT: "Verify successful login"
│   │   │   │
│   │   │   ├── CHECK APP STATE (Modern) - Verify home page
│   │   │   │   Properties:
│   │   │   │   - Target: Home page element (e.g., user menu, dashboard)
│   │   │   │   - Timeout: 30000
│   │   │   │   
│   │   │   │   Found:
│   │   │   │   ├── ASSIGN: loginSuccess = True
│   │   │   │   ├── ASSIGN: status = "Pass"
│   │   │   │   └── LOG MESSAGE: "Login successful"
│   │   │   │   
│   │   │   │   Not Found:
│   │   │   │   ├── ASSIGN: loginSuccess = False
│   │   │   │   ├── ASSIGN: status = "Fail"
│   │   │   │   ├── ASSIGN: errorMsg = "Home page not displayed after login"
│   │   │   │   ├── TAKE SCREENSHOT
│   │   │   │   │   - Save to: "Screenshots\"+testCaseID+"_Fail_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png"
│   │   │   │   │   - Output: screenshotPath
│   │   │   │   └── LOG MESSAGE: "Login failed - home page not found"
│   │   │   │
│   │   │   ├── IF: loginSuccess = True
│   │   │   │   Then:
│   │   │   │   ├── TAKE SCREENSHOT (Evidence)
│   │   │   │   │   - Save to: "Screenshots\"+testCaseID+"_Pass_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png"
│   │   │   │   │   - Output: screenshotPath
│   │   │   │   │
│   │   │   │   └── COMMENT: "Add logout if needed"
│   │   │   │
│   │   │   └── CLOSE APPLICATION
│   │   │
│   │   └── LOG MESSAGE: "Test execution completed: " + status
│   │
│   └── CATCH: System.Exception (variable: exception)
│       │
│       ├── LOG MESSAGE: "Error occurred: " + exception.Message, Level=Error
│       │
│       ├── ASSIGN: status = "Fail"
│       ├── ASSIGN: errorMsg = exception.Message
│       │
│       └── TRY-CATCH (nested for screenshot)
│           Try:
│           └── TAKE SCREENSHOT
│               - Save to: "Screenshots\"+testCaseID+"_Error_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".png"
│               - Output: screenshotPath
│           Catch:
│           └── LOG MESSAGE: "Could not capture screenshot"
│
├── ASSIGN: endTime = DateTime.Now
├── ASSIGN: duration = (endTime - startTime).TotalSeconds
│
├── COMMENT: "Prepare Results Data"
│
├── BUILD DATA TABLE
│   Columns:
│   - Test Case ID (String)
│   - Test Case Name (String)
│   - Execution Date (String)
│   - Start Time (String)
│   - End Time (String)
│   - Duration (sec) (String)
│   - Status (String)
│   - Error Message (String)
│   - Screenshot Path (String)
│   
│   Output: dt_Results
│
├── ADD DATA ROW
│   Properties:
│   - DataTable: dt_Results
│   - ArrayRow: New Object() {
│       testCaseID,
│       testCaseName,
│       DateTime.Now.ToString("yyyy-MM-dd"),
│       startTime.ToString("HH:mm:ss"),
│       endTime.ToString("HH:mm:ss"),
│       duration.ToString("F2"),
│       status,
│       errorMsg,
│       screenshotPath
│     }
│
├── COMMENT: "Write Results to Excel"
│
├── PATH EXISTS
│   - Path: "Data\TestResults.xlsx"
│   - Output: fileExists
│
├── IF: fileExists = False
│   Then:
│   └── CREATE FILE: "Data\TestResults.xlsx"
│       (Create blank Excel with headers)
│
├── EXCEL PROCESS SCOPE (Modern)
│   Properties:
│   - File Path: "Data\TestResults.xlsx"
│   - Read Formatting: False
│   
│   Body:
│   │
│   ├── IF: First run (check if sheet is empty)
│   │   Then:
│   │   └── WRITE